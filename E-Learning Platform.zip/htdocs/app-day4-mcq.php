<?php
session_start();
$name = $_SESSION['username'];
?><!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title></title>
    <link rel="stylesheet" href="assets/css/mcq.css">
    <link rel="stylesheet" href="assets/css/sidebar.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">


</head>

<body>

    <div class="wrapper">
        <!-- Sidebar Holder -->
        <nav id="sidebar" class="bg-dark">
            <div class="sidebar-header b-dark" >
                <h5>Chapter 4:</h5>
                <h5><i class="fa fa-file-text" aria-hidden="true"></i>&nbsp Multiple Choice Question</h5>
            </div>

            <ul class="list-unstyled components">
                <li>
                    <a href="app-day4-module1.php" class="course"><i class="fa fa-circle-o-notch" aria-hidden="true"></i>&nbsp Introduction to API’s</a>
                    <p class="float-right time"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 5min</p>

                </li>
                <br>
                <li>
                  <a href="app-day4-module2.php" class="course"><i class="fa fa-circle-o-notch" aria-hidden="true"></i>&nbsp JSOUP, php parsing</a>
                  <p class="float-right time"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 15min</p>

                </li>
                <br>
                <li>
                  <a href="app-day4-module3.php" class="course"><i class="fa fa-circle-o-notch" aria-hidden="true"></i>&nbsp Instagram Scraping</a>
                  <p class="float-right time"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 35min</p>

                 </li>
                 <br>
                 <li>
                   <a href="app-day4-module4.php" class="course"><i class="fa fa-circle-o-notch" aria-hidden="true"></i>&nbsp Facebook Scraping</a>
                   <p class="float-right time"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 35min</p>

                  </li>
                  <br>
                <li  class="active">
                  <a href="app-day4-mcq.php"><i class="fa fa-certificate" aria-hidden="true"></i>&nbsp MCQ</a>
                </li>
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="#" class="download"><i class="fa fa-file-text" aria-hidden="true"></i>&nbsp Download Material</a>
                </li>
                <li>
                    <a href="app.php" class="article"><i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp Back to Course</a>
                </li>
            </ul>
        </nav>

        <!-- Page Content Holder -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-secondary" style="margin-top:-20px; margin-left:-20px; margin-right:-20px; box-border: 2px 2px solid black">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="navbar-btn bg-secondary">
                        <span class="bg-white"></span>
                        <span class="bg-white"></span>
                        <span class="bg-white"></span>
                    </button>
                    <h6 class="text-white d-none d-lg-block">Multiple Choice Question</h6>

                    <h6 class="text-white"><?php echo "$name";?></h6>
                </div>
            </nav>

            <h2>Multiple Choice Question</h2>

            <div id="container">
                <div id="start">Start Test!</div>
                <div id="quiz" style="display: none">
                    <div id="question"></div>
                    <div id="qImg" class="d-none d-sm-block"></div>
                    <div id="choices">
                        <div class="choice" id="A" onclick="checkAnswer('A')"></div>
                        <div class="choice" id="B" onclick="checkAnswer('B')"></div>
                        <div class="choice" id="C" onclick="checkAnswer('C')"></div>
                    </div>
                    <div id="timer">
                        <div id="counter"></div>
                        <div id="btimeGauge"></div>
                        <div id="timeGauge"></div>
                    </div>
                    <div id="progress"></div>
                </div>


            </div>
            <br>
            <a href="app.php" class="submit-button float-left"><div id="div-button" class="submit-img" style="display: none"></div></a>

        </div>
    </div>
    <script src="assets/js/popper.js" charset="utf-8"></script>
    <script src="assets/js/jquery.min.js" charset="utf-8"></script>
    <script src="assets/js/mcq.js" charset="utf-8"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $(this).toggleClass('active');
            });
        });
    </script>
</body>

</html>

<?php
$link=mysqli_connect("localhost","root","","studentdetails");
$down="";
 ?>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>Report</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
     <link href="https://fonts.googleapis.com/css2?family=Montaga&display=swap" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

     <style media="screen">
       body{
         font-family: "Montaga", serif;

       }
     </style>
   </head>
   <body>
     <center>
       <div class="jumbotron">
         <h1>Attendance Report</h1>
       </div>
       <div class="container">
      <form class="" action="" method="POST" >
       <div class="row">
         <div class="col-md-12">
           <div class="form-group" style="border-radius:20px;">
             <div class="input-group"  >
               <label style="margin-right:30px;font-size:30px;">Select Number of Days :</label>
                 <select id="days" name="days" >
                   <option selected > ---Select No. of days--- </option>
                   <br>
                   <option class="opt">1 </option>
                   <br>
                   <option class="opt">2 </option>
                   <br>
                     <option class="opt">3 </option>
                     <br>
                     <option class="opt">4 </option>
                     <br>
                     <option class="opt">5 </option>
                     <br>
                     <option class="opt">Only 1st day</option><br>
                     <option class="opt">Only 2nd day</option><br>
                     <option class="opt">Only 3rd day</option><br>
                     <option class="opt">Only 4th day</option><br>
                     <option class="opt">Only 5th day</option><br />
                     <option class="opt">Not attended all 5 days</option><br />
                 </select>
               </div>
           </div>
           <div class="form-group">
             <div class="input-group " >
               <input class="btn btn-info" type="submit" name="view" value="View Report">
               </div>
           </div>
           <div class="form-group">
             <div class="input-group " >
               <input class="btn btn-info" type="submit" name="download" value="Download Report">
               </div>
           </div>
         </div>
         </div>
       </form>
         <br><br><br>
         <div class="row">
           <div class="col-md-12">
             <?php
             $output='
             <table width="1200" border="1" style="text-align:center;">
               <tr>
               <td>SNO</td>
               <td>NAME</td>
               <td>E-MAIL</td>
               <td>MOBILE NUMBER</td>
               <td>COURSE</td>
               <td>DAY-1 MCQ</td>
               <td>DAY-2 MCQ</td>
               <td>DAY-3 MCQ</td>
               <td>DAY-4 MCQ</td>
               <td>DAY-5 MCQ</td>
             </tr>';

               if(isset($_POST["view"])){

$nod=$_POST["days"];
               $sno=1;
               #echo $nod;

               if($nod==1){
               $result=mysqli_query($link,"select * from registration_details where day1att=1");
               if($result!=false){
                 while($row=mysqli_fetch_array($result)){
                  $output.=  "<tr> <td>".$sno."</td> <td>".$row["name"]."</td> <td>".$row["email"]."</td> <td>".$row["mobileno1"]."</td> <td>".$row["course"]."</td> <td>".$row["day1score"]."</td> <td>".$row["day2score"]."</td> <td>".$row["day3score"]."</td> <td>".$row["day4score"].
                   "</td> <td>".$row["day5score"]."</td></tr>" ;

                   $sno+=1;
                 }
               }
               $output.='</table>';
               echo $output;
               header("Content-Type: application/xls");
               header("Content-Disposition:attachment; filename=download.xls");
               mysqli_free_result($result);
               mysqli_close($link);

             }     }
             else if(isset($_POST['download'])){
               $nod=$_POST["days"];
               header("Location:download.php?nod=$nod");
             }

                ?>
</table>
           </div>
         </div>
       </div>
     </center>
     <br><br><br>
   </body>


 </html>

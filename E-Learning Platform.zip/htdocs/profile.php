<?php


$link=mysqli_connect("localhost","root","","studentdetails");

$result=mysqli_query($link,"select * from registration_details where id between 1 and 30");

if($result!=false){

while($row=mysqli_fetch_array($result)){
$name=$row["name"];
$course=$row["course"];
$mobile=$row["mobileno1"];
$d1s=$row["day1score"];
$d2s=$row["day2score"];
$d3s=$row["day3score"];
$d4s=$row["day4score"];
$d5s=$row["day5score"];
$d1a=$row["day1att"];
$d2a=$row["day2att"];
$d3a=$row["day3att"];
$d4a=$row["day4att"];
$d5a=$row["day5att"];

if(strtoupper($name[0])=='D'){
echo '<div id="profile" style="background-color:red"><p id="letter">';
echo strtoupper($name[0]);
echo '</p></div>';
}
else if(strtoupper($name[0])=='S'){
echo '<div id="profile" style="background-color:green"><p id="letter">';
echo strtoupper($name[0]);
echo '</p></div>';
}
else if(strtoupper($name[0])=='M'){
echo '<div id="profile" style="background-color:blue"><p id="letter">';
echo strtoupper($name[0]);
echo '</p></div>';
}
else if(strtoupper($name[0])=='A'){
echo '<div id="profile" style="background-color:purple"><p id="letter">';
echo strtoupper($name[0]);
echo '</p></div>';
}
else{
  echo '<div id="profile" style="background-color:orange"><p id="letter">';
  echo strtoupper($name[0]);
  echo '</p></div>';
}
}
/*echo "Name : ".$name."<br />";
echo "Course : ".$course."<br />";
echo "Mobile Number : ".$mobile."<br />";
echo "Day 1 attendance :  ".$d1a. "<br />";
echo "Day 2 attendance :  ".$d2a."<br>";
echo "Day 3 attendance :  ".$d3a."<br>";
echo "Day 4 attendance :  ".$d4a."<br>";
echo "Day 5 attendance :  ".$d5a."<br>";
echo "Day 1 score :  ".$d1s. "<br>";
echo "Day 2 score :  ".$d2s."<br>";
echo "Day 3 score :  ".$d3s."<br>";
echo "Day 4 score :  ".$d4s."<br>";
echo "Day 5 score :  ".$d5s."<br>";
*/
mysqli_free_result($result);
mysqli_close($link);

}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<title>MY PROFILE</title>
    	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Montaga&display=swap" rel="stylesheet">
    	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <style media="screen">
      body{font-family: 'Montaga', serif;}
      #profile{
        border:1px solid orange;
        border-radius:500px;
        width:150px;
        height:150px;
        margin: 10px 10px;
      }
      #letter{
        text-align:center;
        font-size:30px;
        margin-top:50px;
      }
    </style>
  </head>
  <body>

  </body>
</html>

<?php
$conn = mysqli_connect("sql200.epizy.com", "epiz_25696139", "po8USrUTYB10q", "epiz_25696139_vec");
?>
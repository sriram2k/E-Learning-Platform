
<?php

$link=mysqli_connect("localhost","root","","studentdetails");

$nod=$_GET['nod'];

$output= '
<table width="1200" border="1" style="text-align:center;">
  <tr>
  <td>SNO</td>
  <td>NAME</td>
  <td>E-MAIL</td>
  <td>MOBILE NUMBER</td>
  <td>COURSE</td>
  <td>DAY-1 MCQ</td>
  <td>DAY-2 MCQ</td>
  <td>DAY-3 MCQ</td>
  <td>DAY-4 MCQ</td>
  <td>DAY-5 MCQ</td>
</tr> ';

  $sno=1;
  #echo $nod;

  if($nod==1){
  $result=mysqli_query($link,"select * from registration_details where day1att=1");

  if($result!=false){
    while($row=mysqli_fetch_array($result)){
      $output.='<tr> <td>'.$sno.'</td> <td>'.$row["name"].'</td> <td>'.$row["email"].'</td> <td>'.$row["mobileno1"].'</td> <td>'.$row["course"].'</td> <td>'.$row["day1score"].'</td> <td>'.$row["day2score"].'</td> <td>'.$row["day3score"].'</td> <td>'.$row["day4score"].
      '</td> <td>'.$row["day5score"].'</td></tr>' ;

      $sno+=1;
    }
    $output.='</table>';
  }
echo $output;

  mysqli_free_result($result);
  mysqli_close($link);


header("Content-Type: application/xls");
header("Content-Disposition:attachment; filename=download.xls");

}

 ?>

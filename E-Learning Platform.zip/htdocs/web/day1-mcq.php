<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <script src="modenizer.js" type="text/javascript"></script>

<link rel="stylesheet" href="normalise.css">
<link rel="stylesheet" href="../assets/css/mcq.css">
<link rel="stylesheet" type="text/css" href="styles.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>

<header>
  <h3>Web - Day 1 </h3>
  <small>Multiple Choice Quiz </small>
</header>
<div id="emc-score"></div>
<div class="wrap">
  <section data-quiz-item>
    <div class="question">1> Are CSS property names case-sensitive?Ex: <code>baCkgRouNd: #333;</code></div>
    <div class="choices" data-choices='["Yes","No"]'>
    </div>
  </section>
  <section data-quiz-item>
    <div class="question">2> Does setting <code>margin-top:</code> and <code>margin-bottom:</code> have an affect on an inline element?</div>
    <div class="choices" data-choices='["Yes","No"]'>
    </div>
  </section>


  <section data-quiz-item>
    <div class="question">3> The <code>translate()</code> function can move the position of an element on the z-axis.</div>
    <div class="choices" data-choices='["True","False"]'>
    </div>
  </section>
   <section data-quiz-item>
     <div class="question">4> The pseudo class <code>:checked</code> will select inputs with type radio or checkbox, but not option elements.</div>
    <div class="choices" data-choices='["True","False"]'>
    </div>
  </section>


  <section data-quiz-item>
    <div class="question">5> Does setting <code>padding-top:</code> and <code>padding-bottom:</code> on an inline element add to its dimensions?</div>
    <div class="choices" data-choices='["Yes","No","hell no"]'>
    </div>
  </section>
   <section data-quiz-item>
     <div class="question">6> If you have a <code>p</code> element with <code>font-size: 10rem;</code>, will the text be responsive when the user resizes / drags the browser window?</div>
    <div class="choices" data-choices='["Yes","No"]'>
    </div>
  </section>


  <section data-quiz-item>
    <div class="question">7> In a HTML document, the pseudo class <code>:root</code> always refers to the html element.</div>
    <div class="choices" data-choices='["True","False"]'>
    </div>
  </section>
   <section data-quiz-item>
    <div class="question">8> The formula context/target = result is useful when building responsive layouts.</div>
    <div class="choices" data-choices='["True","False"]'>
    </div>
  </section>

  <section data-quiz-item>
    <div class="question">9> Html stands for ____?</div>
    <div class="choices" data-choices='["Hyper text markup language","Cascading stylesheet","hypertext Preprocessor"]'>
    </div>
  </section>

  <div class="submit">
  <!--<button id="emc-submit">Submit Answers</button -->
  <form class="" action="" method="POST">
    <input type="submit" id="emc-submit" name="submit" value="Submit Answers">
  </form>

  </div>
</div>

<?php
if(isset($_POST['submit'])){
  header("Location: ../web.php?msg=completedday1");
  exit();
}
 ?>


<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script>
    var xmlHttp = createXmlHttpRequestObject();

function createXmlHttpRequestObject() {
    var xmlHttp;
    if (window.ActiveXObject) {
        try {
            xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");

        } catch (e) {
            xmlHttp = false;
        }
    } else {
        try {
            xmlHttp = new XMLHttpRequest();
        } catch (e) {
            xmlHttp = false;
        }
    }
    if (!xmlHttp) {
        alert("can't create that object");
    } else {
        return xmlHttp;
    }
}
$(document).ready(function() {


  });

(function($) {
  $.fn.emc = function(options) {

    var defaults = {
      key: [],
      scoring: "normal",
      progress: true
    },
    settings = $.extend(defaults,options),
    $quizItems = $('[data-quiz-item]'),
    $choices = $('[data-choices]'),
    itemCount = $quizItems.length,
    chosen = [],
    $option = null,
    $label = null;

   emcInit();

   if (settings.progress) {
      var $bar = $('#emc-progress'),
          $inner = $('<div id="emc-progress_inner"></div>'),
          $perc = $('<span id="emc-progress_ind">0/'+itemCount+'</span>');
      $bar.append($inner).prepend($perc);
    }


    function emcInit() {
      $quizItems.each( function(index,value) {
      var $this = $(this),
          $choiceEl = $this.find('.choices'),
          choices = $choiceEl.data('choices');
        for (var i = 0; i < choices.length; i++) {
          $option = $('<input name="'+index+'" id="'+index+'_'+i+'" type="radio">');
          $label = $('<label for="'+index+'_'+i+'">'+choices[i]+'</label>');
          $choiceEl.append($option).append($label);

          $option.on( 'change', function() {
            return getChosen();
          });
        }
      });
    }

    function getChosen() {
      chosen = [];
      $choices.each( function() {
        var $inputs = $(this).find('input[type="radio"]');
        $inputs.each( function(index,value) {
          if($(this).is(':checked')) {
            chosen.push(index + 1);
          }
        });
      });
      getProgress();
    }

    function getProgress() {
      var prog = (chosen.length / itemCount) * 100 + "%",
          $submit = $('#emc-submit');
      if (settings.progress) {
        $perc.text(chosen.length+'/'+itemCount);
        $inner.css({height: prog});
      }
      if (chosen.length === itemCount) {
        $submit.addClass('ready-show');
        $submit.click( function(){
          return scoreNormal();
        });
      }
    }

    function scoreNormal() {
      var wrong = [],
          score = null,
          $scoreEl = $('#emc-score');
      for (var i = 0; i < itemCount; i++) {
        if (chosen[i] != settings.key[i]) {
          wrong.push(i);
        }
      }
      $quizItems.each( function(index) {
        var $this = $(this);
        if ($.inArray(index, wrong) !== -1 ) {
          $this.removeClass('item-correct').addClass('item-incorrect');
        } else {
          $this.removeClass('item-incorrect').addClass('item-correct');
        }
      });

      score = Math.floor(((itemCount - wrong.length)).toFixed(2));
       xmlHttp.open("GET", "score-day1.php?score=" +score, true);
    xmlHttp.send(null);
    window.alert("You're Answers Are Submited !! Thank you So much");
    window.location.href = "../web.php";


      }

  }
}(jQuery));


$(document).emc({
  key: ["2","1","2","2","3","2","1","1","1"]
});


  </script>
    <script type="text/javascript" src="modenizer.js"></script>

</body>
</html>
